#include <iostream>
#include <stdexcept>

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    throw std::runtime_error("An error occurred in even more custom application logic.");
    return true;
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e)
    {
        std::cerr << "Exception caught: " << e.what() << std::endl;
    }

    class CustomException : public std::exception
    {
    public:
        const char* what() const noexcept override
        {
            return "Custom exception occurred in custom application logic.";
        }
    };

    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    if (den == 0)
    {
        throw std::overflow_error("Divide by zero exception");
    }
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::overflow_error& e)
    {
        std::cerr << "Exception caught in do_division: " << e.what() << std::endl;
    }
}

int main()
{
    try
    {
        std::cout << "Exceptions Tests!" << std::endl;

        do_division();
        do_custom_application_logic();
    }
    catch (const std::exception& e)
    {
        std::cerr << "Standard exception caught in main: " << e.what() << std::endl;
    }
    catch (...)
    {
        std::cerr << "Unknown exception caught in main." << std::endl;
    }

    return 0;
}